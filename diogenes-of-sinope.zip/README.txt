A Pen created at CodePen.io. You can find this one at https://codepen.io/stefaleon/pen/wGgVLE.

 Tribute Page for a freeCodeCamp challenge