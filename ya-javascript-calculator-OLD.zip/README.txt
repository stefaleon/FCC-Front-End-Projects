A Pen created at CodePen.io. You can find this one at https://codepen.io/stefaleon/pen/ONwRbN.

 Build a JavaScript Calculator
a freeCodeCamp project