function main() {

  var num = "0";
  var result = "0";
  var operation = "addition";
  var display = "0";
  var firstpress = true;  
  $(".output").text(display);
  $("#errmsg").hide();

  console.log("start: num is:" + num + ", result is: " + result +
    ", display is:" + display);

  function initialize() {
    num = "0";
    result = "0";
    operation = "addition";
    display = "0";   
    firstpress = true;
    $(".output").text(display);
    console.log("all init");
    console.log("init: num is:" + num + ", result is: " + result +
      ", display is:" + display);
  };

  function checkErrorLength(str) {
    if (str.length > 12) {      
      $("#errmsg").show();
      setTimeout(function() {
        $("#errmsg").fadeOut(4500);
      }, 500);
      initialize();
    }
  };

  function operate(float1, operation, float2, outcome) {

    if (operation === "division") {
      float2 === 0 ? outcome = null : outcome = float1 / float2;
    } else if (operation === "multiplication") {
      outcome = float1 * float2;
    } else if (operation === "subtraction") {
      outcome = float1 - float2;
    } else if (operation === "addition") {
      outcome = float1 + float2;      
    } else if (operation === "sqrt") {
      outcome = Math.sqrt(float2);
      return outcome;
    } else if (operation === "percent") {
      outcome = float1*float2/100;
      return outcome;
    } else if (operation === "equals") {
      operation = "addition";
      return outcome;
    } 
    operation = "addition";
    return outcome;
  };

  function calculate() {

    console.log("inside calculate now, num is: " + num);
    console.log("inside calculate now, parseFloat(result) is: " + parseFloat(result));
    console.log("inside calculate now, parseFloat(num) is: " + parseFloat(num));
    
    var resultFloat = operate(parseFloat(result), operation, parseFloat(num));
    resultFloat = Math.round(resultFloat*1000)/1000; // to overcome the float inaccuracy
    result = resultFloat.toString();     
    checkErrorLength(result);
    display = result;
    $(".output").text(display);
    num = "";
    

    console.log("display is: " + display);
    console.log("result is: " + result);
    console.log("result.length is: " + result.length);

  };

  $(".number").on("click", function() {
    firstpress = true;
    if (num === "0" && result === "0" && $(this).text !== ".") {
      num = "";
    }
    num += $(this).text();
    checkErrorLength(num);
    display = num;
    $(".output").text(display);

    console.log("$(this).text is: " + $(this).text());
    console.log("num is: " + num);
    console.log("display is: " + display);
  });

  $("#division").on("click", function() {
    console.log("in / now, firstpress is: " + firstpress)
    if (firstpress === true){calculate();}
    firstpress = false;  
    operation = "division";
    console.log("operation is: ", operation);
  });

  $("#multiplication").on("click", function() {
    console.log("in x now, firstpress is: " + firstpress)
    if (firstpress === true){calculate();}
    firstpress = false;  
    operation = "multiplication";
    console.log("operation is: ", operation);
  });

  $("#addition").on("click", function() {
    console.log("in + now, firstpress is: " + firstpress)
    if (firstpress === true){calculate();}
    firstpress = false;  
    operation = "addition";
    console.log("operation is: ", operation);
  });

  $("#subtraction").on("click", function() {
    console.log("in - now, firstpress is: " + firstpress)
    if (firstpress === true){calculate();}
    firstpress = false;    
    operation = "subtraction";
    console.log("operation is: ", operation);
  });

  $("#equals").on("click", function() {
    console.log("in = now, firstpress is: " + firstpress)
    if (firstpress === true){calculate();}
    firstpress = false;  
    operation = "equals";
    num = result;
    result = num;
    num = "";
    operation = "addition";
    console.log("now in equals,  operation is: ", operation);
    console.log("now in equals, num is: " + num);
    console.log("now in equals, parseFloat(result) is: " + parseFloat(result));
    console.log("now in equals, parseFloat(num) is: " + parseFloat(num));
    console.log("now in equals, $(this).text is: " + $(this).text());
    console.log("now in equals, num is: " + num);
    console.log("now in equals, display is: " + display);
  });


  $("#clear").on("click", function() {
    initialize();
  });

  $("#sqrt").on("click", function() {
    //var sqrtbuf = parseFloat(num);    
    //num < 0 ? sqrtbuf = null : sqrtbuf = Math.sqrt(sqrtbuf);
    //sqrtbuf = Math.round(sqrtbuf*1000)/1000;
    //num = sqrtbuf.toString();
    //display = num;
    //$(".output").text(display);
    operation = "sqrt";
    console.log("in sqrt now, firstpress is: " + firstpress)
    calculate();
    firstpress = false;    
    operation = "addition";
    console.log("operation is: ", operation);
    console.log("sqrt pressed");
  });
  
  $("#percent").on("click", function() {
    operation = "percent";
    console.log("in percent now, firstpress is: " + firstpress)
    calculate();
    firstpress = false;    
    operation = "addition";
    console.log("operation is: ", operation);
    console.log("percent pressed");
  });

  $("#toggleplusminus").on("click", function() {
    var togglebuf = parseFloat(num);
    togglebuf = (-togglebuf);
    num = togglebuf.toString();
    display = num;
    $(".output").text(display);
    operation = "addition";
    console.log("toggleplusminus pressed");
  });

} //end main

$(document).ready(main());