$(document).ready(function() {

  //hide tweet anchor
  $("#tweet").hide();

  var receivedQuote = "";
  var twitterQuote = "";
  var jsonUrl = "https://api.icndb.com/jokes/random"; //Chuck Norris Edition

  console.log(jsonUrl);

  //when quotebutton is clicked...
  $("#quotebutton").on("click", function() {
    //remove the paragraphs introduced to #quote div by previous .getJSON
    $("#quote p").remove();

    $.getJSON(jsonUrl, function(x) {

      receivedQuote = x.value.joke;

      twitterQuote = x.value.joke;

      //and appends it to the #quote div
      $("#quote").append("<p>" + receivedQuote + "</p>")
    });
    //Change button text again
    $(this).html("<i class='fa fa-refresh'></i> Load another quote!");
    //show tweet anchor
    $("#tweet").show();
  });

  $("#tweet").on("click", function() {
    $(this).attr("href", 'https://twitter.com/intent/tweet?hashtags=FCC-quotes&text=' + encodeURIComponent(twitterQuote).slice(0, 279));
    //using slice because of the 280 chars limit of twitter and encodeURIcomponent to replace problematic chars 
  });
  

});