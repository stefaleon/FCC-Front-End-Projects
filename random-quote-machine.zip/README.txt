A Pen created at CodePen.io. You can find this one at https://codepen.io/stefaleon/pen/wGjNWY.

 a freeCodeCamp project

Bootstrap 3.3.7 
font-awesome 4.6.1
jQuery 3.3.1
