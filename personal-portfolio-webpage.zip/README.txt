A Pen created at CodePen.io. You can find this one at https://codepen.io/stefaleon/pen/BzLEZN.

 Bootstrap 3.3.6
jQuery-2.2.4