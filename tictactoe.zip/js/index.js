function main() {

  var x = '<p><i class="fa fa-times fa-5x" ></i></p>';
  var o = '<p><i class="fa fa-circle fa-4x" ></i></p>';
  var mySign = "";
  var AISign = "";
  var AIplay = false; // AI's turn to play
  var AIplayChosen = false; // maintain the choice for consecutive replays with begin()
  var sqNum = [1, 2, 3, 4, 5, 6, 7, 8, 9]; // array of available squares
  var ch = ""; // used in play()
  var num = 0; // used in play()
  var AInum = 0; // used in AIplay()
  var playerStr = ""; //string including the numbers of squares occupied by player
  var AIStr = ""; //string including the numbers of squares occupied by AI    
  //var winStr = [123, 456, 789, 147, 258, 369, 159, 357];

  //using click events to overcome asynchronous function access issues

  // clear squares,  
  // initialize array sqNum 
  function init() {
    console.log("now in init()");
    $(".square").html("");
    sqNum = [1, 2, 3, 4, 5, 6, 7, 8, 9];
    playerStr = "";
    AIStr = "";
    console.log(sqNum);
    console.log("init() OK, tableau cleared, sqNum filled");
  } // end of init  

  // game starts with picking a sign, x or o
  // html areas involving first move and winning messages are hidden
  function pickSign() {
    console.log("now in pickSign(), pick a sign");
    $(".starter").hide();
    $(".begin").hide();
    $(".winMessage").hide();
    $(".select").show();
    $("#selx").on("click", function() {
      mySign = x;
      AISign = o;
      $(".select").hide();
      console.log("sign X selected OK");
      $(".starter").show();
    });
    $("#selo").on("click", function() {
      mySign = o;
      AISign = x;
      $(".select").hide();
      console.log("sign O selected OK");
      $(".starter").show();
    });
  } // end of pickSign()

  // after a sign is picked by player, player
  // chooses who gets the first move
  function pickStarter() {
    $("#start").on("click", function() {
      console.log("now in pickStarter()- human start clicked");
      AIplayChosen = false;
      $(".starter").hide();
      $(".begin").show();
      console.log("human plays first");
    });
    $("#AIstart").on("click", function() {
      console.log("now in pickStarter()- AI start clicked");
      AIplayChosen = true;
      $(".starter").hide();
      $(".begin").show();
      console.log("computer plays first");
    });
  } // end of pickStarter()

  // remove the clicked square number n from the square numbers array
  function sqNumSplice(n) {
    //console.log("n is:" + n);
    for (var i = 0; i < sqNum.length; i++) {
      if (sqNum[i] === n) {
        //console.log("sqNum[" + i + "] is:" + sqNum[i] + " type " + typeof(sqNum[i]));
        sqNum.splice(i, 1);
      }
    }
  } // end of aqNumSplice(n)

  // checking if there is a winning move in various stages of the game
  function checkWin(argStr) {
    var argSpl;
    var argSpll;
    if (argStr.length < 3) {
      return false;
    }
    if (argStr.length === 3) {
      if (argStr === "123" || argStr === "456" || argStr === "789" ||
        argStr === "147" || argStr === "258" || argStr === "369" ||
        argStr === "159" || argStr === "357") {
        return true;
      }
    }
    if (argStr.length === 4) {
      for (var j = 0; j < argStr.length; j++) {
        argSpl = argStr.split("");
        argSpl.splice(j, 1);
        console.log(argSpl);
        argSpl = argSpl.join("");
        console.log("j is:" + j + ", argSpl: " + argSpl);
        if (argSpl === "123" || argSpl === "456" || argSpl === "789" ||
          argSpl === "147" || argSpl === "258" || argSpl === "369" ||
          argSpl === "159" || argSpl === "357") {
          return true;
        }
      }
    }
    if (argStr.length === 5) {      
      for (var k = 0; k < 5; k++) {
        argSpl = argStr.split("");
        argSpl.splice(k, 1);        
        for (var l = 0; l < 4; l++) {
          console.log("k is:" + k + ", argSpl: " + argSpl);
          argSpll = argSpl.slice(0);            // using slice to get a COPY of argspl and NOT AFFECT the original
          console.log("l is:" + l + ", argSpll is :" + argSpll);
          argSpll.splice(l, 1);
          console.log(argSpll);
          argSpll = argSpll.join("");
          console.log("l is:" + l + ", argSpll is : " + argSpll + ", argSpl is : " + argSpl);
          if (argSpll === "123" || argSpll === "456" || argSpll === "789" ||
            argSpll === "147" || argSpll === "258" || argSpll === "369" ||
            argSpll === "159" || argSpll === "357") {
            return true;
          }
        }
      }
    }
    return false;
  }

  // initialize with init(),   
  // make all squares clickable 
  // move on with player and AI playing functions
  function begin() {
    $("#idbegin").on("click", function() {
      $(".begin").hide();
      console.log("now in begin()");
      AIplay = AIplayChosen;
      init();
      $(".square").addClass("clickable");
      AIgame();
      play();
      console.log("begin, AIplay is : " + AIplay);
    });
  }

  // AI thinking smart
  // if AI wins select this move
  // else if player wins, block this move
  // else pick center if available
  // else pick a corner
  // else pick random square 
  function selAInum() {
    console.log("in selAInum, sqNum is: " + sqNum);
    var tstAIstr = "";
    var testStr = "";
    var retNum = 0;
    for (var m = 0; m < sqNum.length; m++) {
      tstAIstr = AIStr + sqNum[m];
      tstAIstr = tstAIstr.split("").sort().join("");
      console.log("in selAInum, tstAIstr is: " + tstAIstr)
      if (checkWin(tstAIstr) === true) {
        retNum = sqNum[m];
        console.log("returning retNum: " + retNum);
        return retNum;
      }
    }
    for (var i = 0; i < sqNum.length; i++) {
      testStr = playerStr + sqNum[i];
      testStr = testStr.split("").sort().join("");
      console.log("in selAInum, testStr is: " + testStr)
      if (checkWin(testStr) === true) {
        retNum = sqNum[i];
        console.log("returning retNum: " + retNum);
        return retNum;
      }
    }
    if (sqNum.indexOf(5) > -1) {            // if center is available
      retNum = 5;
      console.log("returning center pick (square number 5): ", retNum);
      return retNum;
    }
    if ((sqNum.indexOf(1) > -1) && ((sqNum.indexOf(2) === -1) || (sqNum.indexOf(4) === -1))){            // if corner 1 is available
      retNum = 1;                                                                           //and not both adjacent squares are empty
      console.log("returning square number 1: ", retNum);
      return retNum;
    }
    if ((sqNum.indexOf(3) > -1) && ((sqNum.indexOf(2) === -1) || (sqNum.indexOf(6) === -1))){            // if corner 3 is available
      retNum = 3;                                                                            //and not both adjacent squares are empty 
      console.log("returning square number 3: ", retNum);
      return retNum;
    }
    if ((sqNum.indexOf(7) > -1) && ((sqNum.indexOf(4) === -1) || (sqNum.indexOf(8) === -1))){            // if corner 7 is available
      retNum = 7;                                                                           //and not both adjacent squares are empty 
      console.log("returning square number 7: ", retNum);
      return retNum;
    }
    if (sqNum.indexOf(9) > -1) {            // if corner 9 is available
      retNum = 9;
      console.log("returning square number 9: ", retNum);
      return retNum;
    }
    retNum = sqNum[Math.floor(Math.random() * sqNum.length)]
    console.log("returning random...", retNum);
    return retNum;
  }

  // a square is selected from AI by selAInum(),
  // then a bit of CSS-jQuery visual effect is performed,
  // selected square number is removed from the square numbers array,
  // number is added to the string including the numbers of squares occupied by AI 
  // then this string is sorted and checked for winning
  // if there is no win and still moves available, get to player to have a move  
  function AIgame() {
    if (AIplay === true) {
      AInum = selAInum();
      console.log("AI's turn, AI picks square with number: " + AInum);
      $("#sq" + AInum).css("opacity", "0.1");
      $("#sq" + AInum).html(AISign).fadeTo(1000, 1);
      $("#sq" + AInum).removeClass("clickable");
      sqNumSplice(AInum); // remove the selected square number from the square numbers array
      AIStr += AInum.toString();
      AIStr = AIStr.split("").sort().join("");
      console.log("AI occupies squares: " + AIStr);
      if (checkWin(AIStr)) {
        victory("AI is");
      } else {
        AIplay = false;
        console.log(sqNum, sqNum.length);
        if (sqNum.length < 1) {
          $(".begin").show();
          begin();
        } else {
          play();
        }
      }
    }
  } // end of AIgame()

  // by clicking on a clickable square, its ID is assigned to ch
  // from then on, the number in the IDstring is removed from sqNum array
  // number is added to the string including the numbers of squares occupied by player 
  // then this string is sorted and checked for winning
  // if there is no win and still moves available, get to AI to have a move  

  function play() {
    $(".square").on("click", function() {
      if (AIplay === false && $(this).attr("class") === "square clickable") {
        $("#" + this.id).css("opacity", "0.1");
        $("#" + this.id).html(mySign).fadeTo(400, 1);
        //console.log("class of clicked square is now: " + $(this).attr("class"));
        $(this).removeClass("clickable");
        //console.log("after toggleClass class of clicked square is now: " + $(this).attr("class"));
        ch = this.id;
        //console.log("the clicked square id is: " + ch, typeof(ch));
        num = parseInt(ch.slice(2)); //stripping the letters off the IDstring, keeping the number
        //console.log("parseInt-square-id -> the clicked square number is: " + num, typeof(num));
        console.log(sqNum, sqNum.length);
        sqNumSplice(num); // remove the clicked square number from the square numbers array
        playerStr += num.toString();
        console.log("player occupies squares: " + playerStr);
        playerStr = playerStr.split("").sort().join("");
        console.log(playerStr);
        if (checkWin(playerStr)) {
          victory("You are");
        } else {
          AIplay = true;
          console.log(sqNum);
          console.log(sqNum.length);
          if (sqNum.length < 1) {
            $(".begin").show();
            begin();
          } else {
            AIgame();
          }
        }
      }
    });
  } // end of play()  

  // if player or AI is victorious
  // give us a flashy message and begin again
  function victory(winner) {
    console.log(winner + " the winner!");
    $(".winMessage").show();
    $(".square").removeClass("clickable");
    $("#winMessID").css("opacity", "0.1");
    $("#winMessID").html(winner + " the winner!").fadeTo(5000, 1);
    $("#spock").on("click", function() {
      $(".winMessage").hide();
      $(".begin").show();
      begin();
    });
  }

  // ok gametime!  
  pickSign();
  pickStarter();
  begin();

} //end main

$(document).ready(main());