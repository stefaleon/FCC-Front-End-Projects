A Pen created at CodePen.io. You can find this one at https://codepen.io/stefaleon/pen/PNdxza.

 a freeCodeCamp challenge

jQuery/2.2.2
Bootstrap/3.3.6
font-awesome/4.6.1

User Stories:
-  I can play a game of Tic Tac Toe with the computer.
-  I can choose whether I want to play as X or O.
-  I can choose who starts the game, I or the computer.
-  My game will reset as soon as it's over so I can play again.
