$(document).ready(function() {

  var searchVar = "";
  var wikiRequest = "";
  var getAndShow = false;

  function getRequest() { //get the search box entry and assign it to wiki api query
    searchVar = document.getElementById("lookfor").value;
    wikiRequest = "https://en.wikipedia.org/w/api.php?action=query&prop=extracts&generator=search&exchars=100&exlimit=max&exintro=1&explaintext=1&gsrsearch=" + searchVar + "&format=json&callback=?";
    getAndShow = true;
  }

  function getResults() {
    //console.log(searchVar);
    if (getAndShow) {
      $("#content").empty();
    }
    $.getJSON(wikiRequest, function(response) {
      var results = response.query.pages;

      console.log(results);
      for (var x in results) {
        //console.log(results[x].title);
        $("#content").append("<p id='result'><a target='_blank' href='https://en.wikipedia.org/wiki/" + encodeURI(results[x].title) + "'><button class='btn btn-default butcust'>" + results[x].title + "<br/>" + results[x].extract + "</p>");
        // console.log(results[x].extract);       
      }
    });
  }

  //when pressing Enter (keycode 13)
  $("#lookfor").on("keypress", function(event) {
    if (event.which === 13) {
      getRequest();
      //console.log("in ENTER code " + wikiRequest);
      getResults();
    }
  });

  //when clicking the adjacent button
  $("#buttonlookfor").on("click", function() {
    getRequest();
    //console.log("in pressbutton code " + wikiRequest);
    getResults();
  });

});