$(document).ready(main());

function main() {

  // variables
  var current = "";  // current number's string
  var previous = "" // previous number's string
  var buffer = "0"; // buffer string
  var operation = ""; // picked operation
  var containsDecimalPoint = false;
  var equalsPressed = false; // used for the case when after some calculation we start another calculation by typing a number without pressing "C" first

  // display buffer (initially a "0")
  $(".output").text(buffer);
  // hide the error message which is hardcoded in the html
  $("#errmsg").hide();

  consoleLogStatus("start");


  // ------------------- click handlers -------------------

  $("#clear").on("click", function()
  // Clear (press "C")
  {
    initialize();
  });

  $(".number").on("click", function()
  // When a number is clicked, it is added as text to the current string
  {
    // clear "operation" after "equals" is pressed and reset equalsPressed to false
    if (equalsPressed) {
      operation = "";
      equalsPressed = false;
    }

    if (current === ".") { current = "0."; } // add a leading zero for decimals in the range (-1, 1)
    if (current === "0") { current = "" } // remove leading zero
    current += $(this).text();
    checkErrorLength(current);
    $(".output").text(current);
    consoleLogStatus("number");
  });

  $("#decimal").on("click", function()
  // decimal point button handler
  {
    if (containsDecimalPoint === false)
    {
      current += $(this).text();
      containsDecimalPoint = true;
    }
    consoleLogStatus("decimal");
  });

  $("#equals").on("click", function() {
    equalsPressed = true;
    if (operation !== "") {
        calculate();
    }
    consoleLogStatus("equals");
  });

  $("#addition").on("click", function() {
    equalsPressed = false;
    if (current) {
      calculate();
    } else {
      previous = buffer; // set "previous" to either initial "0", or to the result of the previous operation since "current" is cleared after each operation
    }
    operation = "addition";
    consoleLogStatus("addition-click");
  });

  $("#subtraction").on("click", function() {
    equalsPressed = false;
    if (current) {
      calculate();
    } else {
      previous = buffer; // set "previous" to either initial "0", or to the result of the previous operation since "current" is cleared after each operation
    }
    operation = "subtraction";
    consoleLogStatus("subtraction-click");
  });

  $("#multiplication").on("click", function() {
    equalsPressed = false;
    if (current) {
      calculate();
    } else {
      previous = buffer; // set "previous" to either initial "0", or to the result of the previous operation since "current" is cleared after each operation
    }
    operation = "multiplication";
    consoleLogStatus("multiplication-click");
  });

  $("#division").on("click", function() {
    equalsPressed = false;
    if (current) {
      calculate();
    } else {
      previous = buffer; // set "previous" to either initial "0", or to the result of the previous operation since "current" is cleared after each operation
    }
    operation = "division";
    consoleLogStatus("division-click");
  });

  $("#sqrt").on("click", function() {
    operation = "sqrt";
    if (current) {
      buffer = current;
      current = "";    
    }
    calculate();
    consoleLogStatus("sqrt-click");
  });

  $("#percent").on("click", function() {
    containsDecimalPoint = false;
    if (!previous) {
      // just calculates current/100
      var resultFloat = parseFloat(current) / 100;
    } else {
      // when an operator is clicked, previous is assigned current's value, now we can enter a new current and
      // calculate expressions such as 300 + 25%
      if (operation === "addition" || operation === "subtraction") {
        var resultFloat = operate(parseFloat(buffer), (parseFloat(buffer) * parseFloat(current) / 100));
      }
      // or 300 * 40%
      if (operation === "multiplication" || operation === "division") {
        var resultFloat = operate(parseFloat(buffer), (parseFloat(current) / 100));
      }
    }
    // "current" has been consumed in the operation, now clear it, but keep its value in "previous"
    previous = current;
    current = "";
    resultFloat = Math.round(resultFloat*1000)/1000; // to overcome the float inaccuracy
    buffer = resultFloat.toString();
    checkErrorLength(buffer);
    $(".output").text(buffer);
    consoleLogStatus("percent-click");
  });

  $("#toggleplusminus").on("click", function() {
    if (current) {
      current = negate(current);
    } else {
      current = negate(buffer);
    }
    $(".output").text(current);
    consoleLogStatus("toggleplusminus");
  });


  // ------------------- helpers -------------------
  function consoleLogStatus(partInCode) {
    console.log("@" + partInCode);
    console.log("--- current:" + current + ", previous: " + previous + ", buffer: " + buffer);
    console.log("--- operation:" + operation);
    console.log("--- containsDecimalPoint: " + containsDecimalPoint );
    console.log("--- equalsPressed:" + equalsPressed);
  };

  function initialize() {
    // reset all
    current = "";
    previous = "";
    buffer = "0";
    operation = "";
    containsDecimalPoint = false;
    equalsPressed = false;
    $(".output").text(buffer);
    consoleLogStatus("initialize");
  };

  function checkErrorLength(str) {
    if (str.length > 12) {
      $("#errmsg").show();
      setTimeout(function() {
        $("#errmsg").fadeOut(4500);
      }, 500);
      initialize();
    }
  };

  function calculate()
  // calculates the operation result and sets it to the buffer
  // if current is not set, previous keeps being used
  {
    containsDecimalPoint = false;
    if (current) {
      var resultFloat = operate(parseFloat(buffer), parseFloat(current));
      // "current" has been consumed in the operation, now clear it, but keep its value in "previous"
      previous = current;
      current = "";
    } else {
      // when we call an operation (press +, -, * or /) without providing a new "current"
      console.log("'current' is null, using 'previous'..."); // previous will be used as operand
      var resultFloat = operate(parseFloat(buffer), parseFloat(previous));
    }
    resultFloat = Math.round(resultFloat*1000)/1000; // to overcome the float inaccuracy
    buffer = resultFloat.toString();
    checkErrorLength(buffer);
    $(".output").text(buffer);
    consoleLogStatus("calculate");
  };

  function operate(float2, float1)
  // performs the operation
  {
    var outcome = float1;   // if operation is null, return the current (or previous) content
    if (operation === "division") {
      outcome = (float1 === 0) ? null : float2 / float1;
    } else if (operation === "multiplication") {
      outcome = float2 * float1;
    } else if (operation === "subtraction") {
      outcome = float2 - float1;
    } else if (operation === "addition") {
      outcome = float2 + float1;
    } else if (operation === "sqrt") {
      outcome = Math.sqrt(float2);
    }
    return outcome;
  };

  function negate(numString) {
    return ( - parseFloat(numString) ).toString();
  }

} //end main