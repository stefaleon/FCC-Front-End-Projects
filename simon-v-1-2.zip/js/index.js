function main() {

  var started = false;
  var strictOn = false;
  var num = 0; // randomly generated 1-4
  var seq = []; // sequence of nums  
  var count = 0; // counter 1-20
  var pNum = 0; // 1-4 produced by clicking on sectors 
  var pCount = 0; // counting player clicks on sectors
  var blinker;
  var seqPlbk;
  var sound1 = new Audio("https://s3.amazonaws.com/freecodecamp/simonSound1.mp3");
  var sound2 = new Audio("https://s3.amazonaws.com/freecodecamp/simonSound2.mp3");
  var sound3 = new Audio("https://s3.amazonaws.com/freecodecamp/simonSound3.mp3");
  var sound4 = new Audio("https://s3.amazonaws.com/freecodecamp/simonSound4.mp3");
  

  function init() {     // clear all
    started = false;
    strictOn = false;
    num = 0;
    seq = [];
    count = 0;
    pNum = 0;
    pCount = 0;
    clearTimeout(blinker);
    clearTimeout(seqPlbk);
    $("#start").removeClass("startLit");
    $(".sector").removeClass("clickable");
    $("#strict").removeClass("strictLit");
    console.log("init ok, seq is: " + seq );
    console.log("started,num,seq,count, pNum ,pCount", started, num, seq, count, pNum, pCount);
  }

  

  // sectID is "#tr" or "#br" or "#bl" or "#tl"
  // tout is timeout, 500 is ok  
  function blink(sectID, tout) {
    blinker = setTimeout(function() {
      $(sectID).css("opacity", "0.3");
      $(sectID).fadeTo(300, 1);
    }, tout);
    console.log(blinker);
  }

  function seqPlayback() {
    console.log("in seqPlayback(), seq is: " + seq);
    $("#display").html(count); 
    started = false;
    $(".sector").removeClass("clickable");
    for (var i = 0; i < seq.length; i++) {
      (function(i) {
        seqPlbk = setTimeout(function() {
          console.log("seq[" + i + "] is: " + seq[i]);
          if (seq[i] === 1) {
            blink("#tr", 200);
            sound1.play();
          } else if (seq[i] === 2) {
            blink("#br", 200);
            sound2.play();
          } else if (seq[i] === 3) {
            blink("#bl", 200);
            sound3.play();
          } else if (seq[i] === 4) {
            blink("#tl", 200);
            sound4.play();
          }
          if (i === seq.length - 1) {
            console.log("sequence played, time for player to play...") 
            started = true;
            $(".sector").addClass("clickable");
          }
        }, 700 * i);
      }(i));
    }
  }

  
  
  function simonSays() {
    count++;
    $("#display").html(count);    
    num = Math.ceil(Math.random() * 4) ; //1 or 2 or 3 or 4
    console.log("num is: " + num);
    seq.push(num);
    console.log("seq is: " + seq);
    seqPlayback();
  }

    
  
  function playerSays() {
    if ( (pCount < seq.length) && (pNum === seq[pCount])) {
      pCount++;
      
      console.log("playerSays pCount now is: " + pCount);
      console.log("playerSays seq.length is: " + seq.length);
      console.log("playerSays, pCount eqs seq.length correct:" + (pCount === seq.length) );
      
      if ( pCount === seq.length){        
        if (pCount === 20) {// score limit  
          $("#display").css("opacity", "0.6");
          $("#display").html("win*").fadeTo(3000, 1);
          init();
          setTimeout(function(){
            $("#display").html("");
          }, 9000);
          return;
        }
        else {
          pCount = 0;
          console.log("NICE, pCount now is: " + pCount);
          $("#display").css("opacity", "0.6");
          $("#display").html("NICE").fadeTo(1000, 1);       
          setTimeout(function(){
            simonSays();
          }, 1200);
        }        
       } 
      }  
      else if (pNum !== seq[pCount]) {        
        pCount = 0;
        started = false;
        $(".sector").removeClass("clickable");
        clearTimeout(seqPlbk);
        console.log("pNum not equal to seq[pCount], pCount is:" + pCount);
        $("#display").css("opacity", "0.6");
        $("#display").html("WRNG").fadeTo(5000, 1);
        if (strictOn){
          $("#display").css("opacity", "0.6");
          $("#display").html("LOST").fadeTo(5000, 1);
          setTimeout(function(){
            init();
          }, 3200);
        }
        else {
          setTimeout(function(){
            seqPlayback();
          }, 1200);                              
        }        
      }   
  }

  
  
  
  $("#start").on("click", function() {
    started = true;
    $("#start").addClass("startLit");
    $(".sector").addClass("clickable");
    simonSays();
  });

  $("#strict").on("click", function() {    
    if (started === false) {
      $("#display").html("srct");
      $(this).addClass("strictLit");
      strictOn = true;      
    }
  });

  $("#stop").on("click", function() {
    $("#display").html("stop");
    init();
    setTimeout(function(){
            $("#display").html("");
          }, 2500);
  });

  $(".sector").on("click", function() {
    if (started) {
      $(this).css("opacity", 0.5);
      $(this).fadeTo(400, 1);
      if (this.id === "tr") {
        pNum = 1;
        sound1.play();
      } else if (this.id === "br") {
        pNum = 2;
        sound2.play();
      } else if (this.id === "bl") {
        pNum = 3;
        sound3.play();
      } else if (this.id === "tl") {
        pNum = 4;
        sound4.play();
      }
      
      console.log("player click, this.id is:" + this.id);
      console.log("player click, pNum is:" + pNum + " type " + typeof(pNum));
      console.log("player click, pCount is:" + pCount);
      console.log("player click, seq[pCount] is:" + seq[pCount] + " type " + typeof(seq[pCount]));
      console.log("player click, pNum+seq[pCount] correct:" + (pNum === seq[pCount])  );
      
      playerSays();
        
      
    }
 });

} // end of main()

$(document).ready(main());