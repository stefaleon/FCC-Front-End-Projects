A Pen created at CodePen.io. You can find this one at https://codepen.io/stefaleon/pen/NYWoom.

 CSS
normalize 8.0.0
skeleton 2.0.4