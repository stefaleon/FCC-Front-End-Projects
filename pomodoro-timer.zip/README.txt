A Pen created at CodePen.io. You can find this one at https://codepen.io/stefaleon/pen/zqJOrX.

 a freeCodeCamp challenge
jQuery/2.2.2
Bootstrap/3.3.6
font-awesome/4.6.1