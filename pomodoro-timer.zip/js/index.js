function main(){

 //Notifications Enabling Code from http://stackoverflow.com/a/13328397/1269037
 
  // request permission on page load
document.addEventListener('DOMContentLoaded', function () {
  if (Notification.permission !== "granted")
    Notification.requestPermission();
});

/* 
  function notifyMe() {
  if (!Notification) {
    alert('Desktop notifications not available in your browser. Try Chromium.'); 
    return;
  }

  if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notification title', {
      icon: 'http://cdn.sstatic.net/stackexchange/img/logos/so/so-icon.png',
      body: "Hey there! You've been notified!",
    });

    notification.onclick = function () {
      window.open("http://stackoverflow.com/a/13328397/1269037");      
    };
    
  }

}*/
  
function notifyMe() {
  if (!Notification) {
    alert('Desktop notifications not available in your browser. Try Chromium.'); 
    return;
  }

  if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('Notification title', {
      icon: 'http://cdn.sstatic.net/stackexchange/img/logos/so/so-icon.png',
      body: "Pomodoro your time!",
    });

    notification.onclick = function () {
      window.open(document);      
    };
    
  }

}
 

var dur = 25; // in minutes
var i = dur*60;   
var interval;
var nowCounting = false;
console.log("duration of countdown is: " + dur +" seconds.");
var breakDur = 5;
var j = breakDur; 
var breakInterval;
var nowBreakCounting = false;
var pause = false;  
console.log("duration of break countdown is: " + breakDur +" seconds.");
var whistle = new Audio("http://soundbible.com/grab.php?id=2103&type=mp3");
var tuneIn = new Audio("http://soundbible.com/grab.php?id=2099&type=mp3");  

  
  
  
//display  
$("#duration").text(ddd(dur));
$("#breakDuration").text(ddd(breakDur));

   
  
 function outputTime(t) {
   $(".output").text(  ddd( Math.floor(t/60) ) + ":" + ddd(t%60)  );   
 } 
 
  
 //display double digit 
 function ddd(x) {               
  return ("0" + x).slice(-2);
}   
  
// session length customization
$("#durDecrease").on("click", function() {
  if ( nowCounting === false && nowBreakCounting === false) {
  if (dur > 1) { dur--; 
                console.log("dur:" + dur)
                $("#duration").text(ddd(dur)); 
                initialize();
               }
  }
  });

$("#durIncrease").on("click", function() {
  if ( nowCounting === false && nowBreakCounting === false) {
  if (dur < 60 ) { dur++; 
                console.log("dur:" + dur);
                $("#duration").text(ddd(dur)); 
                initialize();
               }
  }
  });

   
  
  // break length customization
$("#breakDurDecrease").on("click", function() {
  if ( nowCounting === false && nowBreakCounting === false) {
  if (breakDur > 1) { breakDur--; 
                console.log("breakDur:" + breakDur)
                $("#breakDuration").text(ddd(breakDur)); 
                initialize();
               }
  }
  });

$("#breakDurIncrease").on("click", function() {
  if ( nowCounting === false && nowBreakCounting === false) {
  if (breakDur < 60 ) { breakDur++; 
                console.log("breakDur:" + breakDur);
                $("#breakDuration").text(ddd(breakDur)); 
                initialize();
               }
  }
  });
  
  
   
  
  
  
function initialize() {
  i = dur*60; 
  nowCounting = false;
  j = breakDur*60; 
  nowBreakCounting = false;
  outputTime(i);    
  console.log("init OK");  
}  
    
  
function startCountdown() {  
  if(nowCounting === false && i>0){ 
    nowCounting = true;
    console.log("start, nowCounting is: " + nowCounting);
    notifyMe();
    alert("May the force be with you!");    
    interval = setInterval(function(){      
      i--;
      console.log(i);       
      $(".message").text("Keep up the good work!");
      outputTime(i);
      if ( i === 0 ){
        stopCountdown();
        whistle.play();
        initialize(); 
        startBreakCountdown();
      }    
    }, 1000);    
 }
}

function stopCountdown() {
  clearInterval(interval);  
  clearInterval(breakInterval);
  initialize();
  $(".message").text("Stopped me now!");
  console.log("stop, nowCounting is: " + nowCounting);
  console.log("stop, nowBreakCounting is: " + nowBreakCounting);
}
  
function startBreakCountdown() {    
  if(nowBreakCounting === false && j>0){ 
    nowBreakCounting = true;
    console.log("start, nowBreakCounting is: " + nowBreakCounting);
    notifyMe();
    alert("Break time! Stretch your legs!");    
    breakInterval = setInterval(function(){      
      j--;
      console.log(j); 
      $(".message").text("Time to relax!");
      outputTime(j);
      if ( j === 0){
        stopCountdown();
        tuneIn.play();
        initialize(); 
        startCountdown();
      }
    } , 1000);    
 }
}  
  

function pauseCountdown() {
  pause = true;
  $(".message").text("All work no play...");
  clearInterval(interval);  
  clearInterval(breakInterval);
  console.log("pause is: " + pause);
  console.log("pause, nowCounting is: " + nowCounting);
  console.log("pause, i is: " + i);
  console.log("pause, nowBreakCounting is: " + nowBreakCounting);
  console.log("pause, j is: " + j);
}

function resumeCountdown() {    
  if(pause && nowCounting){  
    pause = false;
    console.log("pause is: " + pause);
    console.log("resume, nowCounting is: " + nowCounting);
      $(".message").text("Keep up the good work!");
    interval = setInterval(function(){
      i--;
      console.log(i); 
      outputTime(i);
      if ( i === 0 ){
        stopCountdown();
        initialize(); 
        startBreakCountdown();
      }
    }, 1000);    
 }
 else if(pause && nowBreakCounting){
   pause = false;   
   console.log("pause is: " + pause);
   console.log("resume, nowBreakCounting is: " + nowBreakCounting);
     $(".message").text("Relax! Don't do it!");
   breakInterval = setInterval(function(){
     j--;
     console.log(j); 
     outputTime(j)
     if ( j === 0 ){
       stopCountdown();
       initialize(); 
       startCountdown();
      }
    }, 1000);    
 } 
 else {
   startCountdown();
 } 
}

initialize();
$(".message").text("Work long and prosper!");
$("#startCountdown").on("click", function() {
startCountdown();
});
$("#stopCountdown").on("click", function() {
stopCountdown();
});
$("#pauseCountdown").on("click", function() {
pauseCountdown();
});
$("#resumeCountdown").on("click", function() {
resumeCountdown();
});


}


$(document).ready(main());